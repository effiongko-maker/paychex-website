from pathlib import Path
import shutil
root=Path.cwd()
hero=root/'components/sections/home/HomeHero.tsx'
source=Path(__file__).resolve().parent/'components/sections/home/CapabilitySystem.tsx'
if not hero.is_file() or not (root/'package.json').is_file():
    raise SystemExit('Run from the PayChex website repository root.')
text=hero.read_text()
old='import { EditorialMedia } from "@/components/patterns/EditorialMedia";'
if old not in text and 'import { CapabilitySystem }' not in text:
    raise SystemExit('Expected HomeHero import not found; no changes made.')
text=text.replace(old,'import { CapabilitySystem } from "@/components/sections/home/CapabilitySystem";')
text=text.replace('  homeHeroMedia,\n  homeHeroMediaOverlay,\n','')
text=text.replace('<EditorialMedia\n                source={homeHeroMedia}\n                overlayOpacity={homeHeroMediaOverlay}\n              />','<CapabilitySystem />')
if '<CapabilitySystem />' not in text:
    raise SystemExit('Expected EditorialMedia JSX not found; no changes made.')
target=root/'components/sections/home/CapabilitySystem.tsx'
shutil.copyfile(source,target)
hero.write_text(text)
print('Installed modular hero. Existing copy, CTAs, and metrics retained.')
