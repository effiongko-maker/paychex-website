from pathlib import Path
import shutil
root=Path.cwd()
hero=root/'components/sections/home/HomeHero.tsx'
metrics=root/'components/sections/home/ImpactMetricsPanel.tsx'
target=root/'components/sections/home/CapabilitySystem.tsx'
if not hero.is_file() or not metrics.is_file() or not (root/'package.json').is_file():
    raise SystemExit('Run from PayChex website repository root')
h=hero.read_text(); m=metrics.read_text()
if '<CapabilitySystem />' not in h:
    raise SystemExit('Expected modular hero not found. Apply the previous modular hero package first.')
if 'inline?: boolean' not in m:
    m=m.replace('export function ImpactMetricsPanel() {','export function ImpactMetricsPanel({ inline = false }: { inline?: boolean }) {')
    m=m.replace('"absolute bottom-5 left-0 z-10 hidden w-[13.5rem] -translate-x-10 lg:block xl:bottom-7 xl:-translate-x-14",','inline
          ? "relative mt-3 w-full"
          : "absolute bottom-5 left-0 z-10 hidden w-[13.5rem] -translate-x-10 lg:block xl:bottom-7 xl:-translate-x-14",')
    m=m.replace('"border border-white/40 bg-surface/70 px-8 py-7",','inline
          ? "border border-border-subtle bg-surface px-5 py-4"
          : "border border-white/40 bg-surface/70 px-8 py-7",')
    m=m.replace('"shadow-[0_18px_50px_-28px_rgb(0_0_0_/0.28)] backdrop-blur-md",','inline ? "" : "shadow-[0_18px_50px_-28px_rgb(0_0_0_/0.28)] backdrop-blur-md",')
if '<ImpactMetricsPanel inline />' not in h:
    h=h.replace('<ImpactMetricsPanel />','<ImpactMetricsPanel inline />')
if '<ImpactMetricsPanel inline />' not in h or 'inline?: boolean' not in m:
    raise SystemExit('Expected modifications not applied')
shutil.copyfile(Path(__file__).resolve().parent/'CapabilitySystem.tsx',target)
metrics.write_text(m); hero.write_text(h)
print('Updated five independent service modules without integration messaging and relocated trust signal below visual.')
